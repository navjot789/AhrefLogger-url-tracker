<?php
 if(isset($_GET['link']) ) 
 {
     header('location:https://ahrefs.tech/index?link='.$_GET['link']);
     exit();
 }
 else
 {
     header('location:https://ahrefs.tech/');
     exit();
 }
?>